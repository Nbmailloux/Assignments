var express = require('express');
var hbs = require('hbs');
var hoteljsonFile = require("./todo.json"); 
var app = express();

app.set('view engine', 'hbs');

hbs.registerPartials(__dirname + '/views/partials');

app.use(express.urlencoded());

app.use(express.static(__dirname + '/public'));

app.get('/', (req, res)=>{
    res.render('index.hbs',{title:"Index"});
});

app.get('/todo.json', (req, res)=>{
    res.sendFile("todo.json");
});

app.get('/readtodo', (req, res)=>{
    res.render('read-todo.hbs',{title:"Read-todo"});
});

app.get('/todo', (req, res)=>{
    res.send(hoteljsonFile);
});

app.get('*', (req, res)=>{
    res.render('index.hbs',{title:"Index"});
});



app.listen(3000, ()=>{
    console.log('Server is up at localhost:3000')
})

