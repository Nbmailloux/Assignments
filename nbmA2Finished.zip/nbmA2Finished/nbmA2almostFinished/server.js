var express = require('express');
var hbs = require('hbs');


var app = express();

app.set('view engine', 'hbs');

hbs.registerPartials(__dirname + '/views/partials');

app.use(express.urlencoded({extended:false}));

app.use(express.static(__dirname + '/public'));

hbs.registerHelper('ptag',(name, comments, email)=>{
    var msg = '';
        

   msg += `<body style="background-color:powderblue;"><a href='http://localhost:3000/index'>Index</a>
    <a href='http://localhost:3000/About'>About</a>
    <a href='http://localhost:3000/Form'>Form</a></br>`;
        msg+=`<body><p><b>Name:</b>  ${name}</p>`;
        msg+=`<p><b>Email:</b>  ${email}</p>`;
        msg+=`<p><b>Comments:</b>  ${comments}</p></body>`;
    
    return new hbs.handlebars.SafeString(msg);
});

app.get('/', (req, res)=>{
    res.render('index.hbs',{title:"Index"});
    //res.send("<html><head><title></title><head><body><h1>Landing/Form Page</h1></body><html>");
});

app.get('/index', (req, res)=>{
    res.render('index.hbs',{title:"Index"});
});

app.get('/about', (req, res)=>{

    res.render('about.hbs',{title:"About"});
});

app.get('/form', (req, res)=>{

    res.render('form.hbs',{title:"Form"});
});

app.post('/results',(req,res)=>{
    res.render('results.hbs',{
        rName:req.body.name,
        rComments:req.body.comments,
        rEmail:req.body.email
    })
})



app.listen(3000, ()=>{
    console.log('Server is up at localhost:3000')
})